﻿using NWVDNUG.Entities;

namespace NWVDNUG.ViewModels
{
    public class HomePageViewModel
    {
        public Meeting NextMeetingInfo { get; set; }
    }
}